# DS Review

ИИ-навык для ревью макетов Figma на соответствие дизайн-системе **🍏 Pole Mobile 2.0**.
Даёшь ИИ ссылку на экран или секцию с флоу — он проверяет макет по **✅ Checklist DS** и паттернам Magnit app 2.0 и ставит пометки прямо на слои.
В каждой пометке: что не так, как исправить, ссылка на гайд.

Формат — открытый стандарт Agent Skills (`SKILL.md`). Работает в Claude, Cursor, Codex, Gemini CLI и других ИИ, которые поддерживают навыки и Figma MCP.

## Что проверяется

| Пункт чек-листа | Как |
|---|---|
| Файл обновлен | Частично автоматически: токены старой версии библиотеки. Остальное — вручную |
| Токены и компоненты из либы с 🍏 | Автоматически: устаревшие и веб-компоненты, hex, примитивы палитры, устаревшие токены и стили, текст без стиля |
| Токены отступов Spacing в контейнере с секциями и во врезках | Автоматически |
| Токены скруглений Container в секциях, блоках и карточках | Автоматически |
| Компоненты не закастомлены | Автоматически: переопределения цвета, отступов, скруглений, типографики, теней, прозрачности |
| Компоненты не раздетачены | Автоматически |
| Паттерны Magnit app 2.0 | Автоматически: порядок кнопок, Primary для «Назад», шторки, собранные вручную, «красный крест». Остальное — ИИ по скриншоту и структуре экрана |

Тёмную тему, анимации, тексты и процессы других команд навык не проверяет. Компоненты 🍋 (Платформа) и 🍏 Platform Components 2.0 не проверяются.

## Как пользоваться

### 1. Подключи Figma к своему ИИ

Нужен Figma MCP — сервер `https://mcp.figma.com/mcp`.
- В Claude это коннектор Figma.
- В Cursor, VS Code и других — добавь сервер в настройках MCP.

Для пометок нужны права на редактирование файла.

### 2. Установи навык

Скачай папку `ds-review/` из репозитория.

| ИИ | Куда положить |
|---|---|
| Claude (десктоп и claude.ai) | Запакуй папку `ds-review` в ZIP → Customize → Skills → «+» → Create skill → Upload a skill. Владелец организации может включить навык сразу всем |
| Cursor | `.cursor/skills/ds-review/` в проекте или `~/.cursor/skills/ds-review/` |
| Codex | `.codex/skills/ds-review/` или `~/.codex/skills/ds-review/` |
| Gemini CLI | `.gemini/skills/ds-review/` или `~/.gemini/skills/ds-review/` |

Без установки: если ИИ умеет читать ссылки, а репозиторий открыт на чтение, напиши:
«Прочитай `<ссылка на ds-review/SKILL.md>` и все файлы рядом, затем проведи DS-ревью `<ссылка на макет>`».

### 3. Попроси ревью

> Проведи DS-ревью: https://www.figma.com/design/…?node-id=12-34

Ссылка — на **экран** или **секцию с флоу**, не на страницу целиком.

Ещё команды:
- «Только отчёт, без пометок»
- «Перепроверь» — старые пометки заменятся новыми
- «Убери пометки DS Review»

Пометки — это аннотации Figma в категории **DS Review**. Чужие аннотации навык не трогает.

## Как дорабатывать

| Что поменять | Где |
|---|---|
| Порядок ревью, тон, формат сводки | `ds-review/SKILL.md` |
| Пункты чек-листа, критичность | `ds-review/references/checklist.md` и `CHECK` в `scripts/annotate.js` |
| Значения и правила токенов | `ds-review/references/tokens.md` |
| Эмодзи-маркеры, библиотеки, что считать кастомизацией | `CFG` в `scripts/audit.js` и `references/components.md` |
| Устаревшие компоненты («Кладбище») | `CFG.deprecatedKeys` в `scripts/audit.js` |
| Правила паттернов | `ds-review/references/patterns.md` |
| Ссылки на гайды в пометках | `LINKS` в `scripts/annotate.js`, страницы компонентов — `COMP_PAGES` в `scripts/audit.js` |

Порядок изменений:
1. Ветка → правка → merge request.
2. Прогони навык на макетах из `tests/examples.md` и сверь с ожидаемыми находками.
3. Запиши изменения в `CHANGELOG.md` и подними версию.
4. После merge — новый ZIP для тех, кто ставил навык в Claude: Customize → Skills → удалить старый → загрузить новый.

`tools/check.sh` проверяет синтаксис скриптов (`node` ≥ 18), что они укладываются в лимит `use_figma` (50 000 символов), и запускает автотест `tests/mock-audit.mjs`: каждое правило проверяется на заглушке Figma API. Он же запускается в CI. Добавил правило — добавь его случай в автотест.

## Структура

```
ds-review/            ← сам навык (эту папку устанавливают)
  SKILL.md            ← инструкция для ИИ
  scripts/
    audit.js          ← автопроверка (только чтение)
    outline.js        ← структура экранов для проверки паттернов (только чтение)
    annotate.js       ← ставит и убирает пометки
  references/
    checklist.md      ← ✅ Checklist DS и правила
    tokens.md         ← токены
    components.md     ← библиотеки, маркеры, кастомизация
    patterns.md       ← паттерны
tests/examples.md     ← макеты для проверки навыка и эталонное ревью
tests/mock-audit.mjs  ← автотест правил
tools/check.sh        ← проверка синтаксиса
CHANGELOG.md
```

## Источники

- [🍏 Pole Mobile 2.0](https://www.figma.com/design/tN0vhB9QeckIvUKC6T8zWb/Pole-Mobile-2.0?node-id=56968-35493)
- [🍏 Patterns Magnit app 2.0](https://www.figma.com/design/XgGTUV55rY4ni69XnFYXVJ/Patterns-Magnit-app-2.0?node-id=1-2)
- [✅ Checklist DS](https://www.figma.com/design/ef78UYFlsx3lyBWgHpsB3h/Tools?node-id=546-633)
- [🍏 Icons 2.0](https://www.figma.com/design/ep0MkPmVw5fxARZcZ0HEue/Icons-2.0?node-id=1-2)
- [🍏 Illustration 2.0](https://www.figma.com/design/Qm4IeMA7UANKaANCRHmYHA/Illustration-2.0?node-id=20-31)
